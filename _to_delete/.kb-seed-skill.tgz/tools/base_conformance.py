#!/usr/bin/env python3
"""
Base-conformance gate (KEP). beckn-base.yaml is the HUMAN-OWNED authority.
The skill grounds against it and NEVER rewrites it. This tool checks each config
book against the base and RAISES deviations: a schema / field / enum value a config
uses that the base does not cover. On any deviation the skill must STOP seeding the
deviating element and ask the USER to update common-config/beckn-base.yaml manually.

Output: knowledge/_work/base-conformance.json  ·  exit 0 = conformant, 3 = deviations.
"""
import os, sys, json, yaml, _env

def load(p):
    try: return yaml.safe_load(open(p))
    except Exception: return {}

def schemas_of(spec): return (spec.get("components",{}) or {}).get("schemas",{}) or {}
def props(sc):
    p = {}
    if isinstance(sc, dict):
        p.update(sc.get("properties") or {})
        for a in sc.get("allOf",[]) or []:
            if isinstance(a, dict): p.update(a.get("properties") or {})
    return p
def enum_of(d): return set(map(str, d.get("enum", []))) if isinstance(d, dict) else set()

def run():
    if not os.path.exists(_env.BECKN_BASE):
        print("STOP: beckn-base.yaml (human-owned authority) is missing — cannot check conformance."); sys.exit(2)
    base = schemas_of(load(_env.BECKN_BASE))
    report, total = {}, 0
    for book in _env.discover_books():
        bid = _env.book_id(book)
        cfg = schemas_of(load(os.path.join(book, "config", "specs", "openapi.yaml")))
        devs = []
        for name, sc in cfg.items():
            if name not in base:
                devs.append({"type":"new-schema", "at":name}); continue
            bprops = props(base[name])
            for field, fdef in props(sc).items():
                if field not in bprops:
                    devs.append({"type":"new-field", "at":f"{name}.{field}"})
                else:
                    extra = enum_of(fdef) - enum_of(bprops[field])
                    # normalize hyphen/underscore + case before flagging enum drift
                    norm = lambda s: {v.upper().replace("_","-") for v in s}
                    if norm(enum_of(fdef)) - norm(enum_of(bprops[field])):
                        devs.append({"type":"new-enum-value", "at":f"{name}.{field}",
                                     "values": sorted(norm(enum_of(fdef)) - norm(enum_of(bprops[field])))[:6]})
        report[bid] = {"deviation_count": len(devs), "deviations": devs[:40]}
        total += len(devs)
    verdict = "CONFORMANT" if total == 0 else "DEVIATIONS"
    report["_verdict"] = verdict; report["_total"] = total
    os.makedirs(_env.WORK, exist_ok=True)
    json.dump(report, open(_env.w("base-conformance.json"), "w"), indent=2)

    print(f"BASE CONFORMANCE — {verdict} ({total} deviation(s))\n")
    for bid, r in report.items():
        if bid.startswith("_"): continue
        print(f"  {bid}: {r['deviation_count']} deviation(s)")
        for d in r["deviations"][:6]:
            print(f"      {d['type']:15} {d['at']}" + (f"  {d.get('values')}" if d.get("values") else ""))
    if total:
        print("\n⚠ RAISED: configs deviate from the human-owned beckn-base.")
        print("  → Update common-config/beckn-base.yaml MANUALLY to cover these, then re-run.")
        print("  → The skill will NOT modify the base; deviating elements are held out of seeding until reconciled.")
    else:
        print("\n✓ All configs conform to the base — safe to ground against it.")
    sys.exit(3 if total else 0)

if __name__ == "__main__":
    run()
