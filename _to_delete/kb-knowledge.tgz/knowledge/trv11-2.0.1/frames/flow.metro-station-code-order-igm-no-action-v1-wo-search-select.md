---
id: flow.metro-station-code-order-igm-no-action-v1-wo-search-select
kind: instance
layer: domain
status: draft
asof: trv11-2.0.1
---

# flow.metro-station-code-order-igm-no-action-v1-wo-search-select

Declared node for `flow.metro-station-code-order-igm-no-action-v1-wo-search-select` — metro station code order igm no action v1 wo search select.

Grounded at: `trv11-2.0.1:flows/Metro/STATION_CODE_FLOW_ORDER_IGM_No_Action_v-1_0_0__W_O_Search_and_Select_.yaml#meta.description`

Seeded by Stage E interpretation; body intentionally light — the facts live in
`atoms.md`, not in prose.
