---
id: flow.bus-vehicle-based-confirmation-with-update
kind: instance
layer: domain
status: draft
asof: trv11-2.1.0
---

# flow.bus-vehicle-based-confirmation-with-update

Declared node for `flow.bus-vehicle-based-confirmation-with-update` — bus vehicle based confirmation with update.

Grounded at: `trv11-2.1.0:flows/Bus/IntraCity_Vehicle_Based_Confirmation_flow_With_Update_Call_.yaml#meta.flowId`

Seeded by Stage E interpretation; body intentionally light — the facts live in
`atoms.md`, not in prose.
